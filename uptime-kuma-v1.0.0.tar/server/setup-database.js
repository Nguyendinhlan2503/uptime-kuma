const express = require("express");
const { log } = require("../src/util");
const expressStaticGzip = require("express-static-gzip");
const fs = require("fs");
const path = require("path");
const Database = require("./database");
const { allowDevAllOrigin } = require("./util-server");
const mysql = require("mysql2/promise");

/**
 *  A standalone express app that is used to setup a database
 *  It is used when db-config.json and kuma.db are not found or invalid
 *  Once it is configured, it will shut down and start the main server
 */
class SetupDatabase {
    /**
     * Show Setup Page
     * @type {boolean}
     */
    needSetup = true;
    /**
     * If the server has finished the setup
     * @type {boolean}
     * @private
     */
    runningSetup = false;
    /**
     * @inheritDoc
     * @type {UptimeKumaServer}
     * @private
     */
    server;

    /**
     * @param  {object} args The arguments passed from the command line
     * @param  {UptimeKumaServer} server the main server instance
     */
    constructor(args, server) {
        this.server = server;
        this.basePath = args["base-path"] || process.env.UPTIME_KUMA_BASE_PATH || "";
        // Normalize base path
        if (this.basePath) {
            this.basePath = this.basePath.startsWith("/") ? this.basePath : "/" + this.basePath;
            this.basePath = this.basePath.replace(/\/$/, "");
        }

        // Priority: env > db-config.json
        // If env is provided, write it to db-config.json
        // If db-config.json is found, check if it is valid
        // If db-config.json is not found or invalid, check if kuma.db is found
        // If kuma.db is not found, show setup page

        let dbConfig;

        try {
            dbConfig = Database.readDBConfig();
            log.debug("setup-database", "db-config.json is found and is valid");
            this.needSetup = false;

        } catch (e) {
            log.info("setup-database", "db-config.json is not found or invalid: " + e.message);

            // Check if kuma.db is found (1.X.X users), generate db-config.json
            if (fs.existsSync(path.join(Database.dataDir, "kuma.db"))) {
                this.needSetup = false;

                log.info("setup-database", "kuma.db is found, generate db-config.json");
                Database.writeDBConfig({
                    type: "sqlite",
                });
            } else {
                this.needSetup = true;
            }
            dbConfig = {};
        }

        if (process.env.UPTIME_KUMA_DB_TYPE) {
            this.needSetup = false;
            log.info("setup-database", "UPTIME_KUMA_DB_TYPE is provided by env, try to override db-config.json");
            dbConfig.type = process.env.UPTIME_KUMA_DB_TYPE;
            dbConfig.hostname = process.env.UPTIME_KUMA_DB_HOSTNAME;
            dbConfig.port = process.env.UPTIME_KUMA_DB_PORT;
            dbConfig.dbName = process.env.UPTIME_KUMA_DB_NAME;
            dbConfig.username = process.env.UPTIME_KUMA_DB_USERNAME;
            dbConfig.password = process.env.UPTIME_KUMA_DB_PASSWORD;
            Database.writeDBConfig(dbConfig);
        }

    }

    /**
     * Show Setup Page
     * @returns {boolean} true if the setup page should be shown
     */
    isNeedSetup() {
        return this.needSetup;
    }

    /**
     * Check if the embedded MariaDB is enabled
     * @returns {boolean} true if the embedded MariaDB is enabled
     */
    isEnabledEmbeddedMariaDB() {
        return process.env.UPTIME_KUMA_ENABLE_EMBEDDED_MARIADB === "1";
    }

    /**
     * Start the setup-database server
     * @param {string} hostname where the server is listening
     * @param {number} port where the server is listening
     * @returns {Promise<void>}
     */
    start(hostname, port) {
        return new Promise((resolve) => {
            const app = express();
            let tempServer;
            app.use(express.json());

            // Disable Keep Alive, otherwise the server will not shutdown, as the client will keep the connection alive
            app.use(function (req, res, next) {
                res.setHeader("Connection", "close");
                next();
            });

            // Create router for base path if needed
            const router = this.basePath ? express.Router() : app;

            router.get("/", async (request, response) => {
                // Serve HTML and let Vue Router handle the routing
                let html = this.server.originalIndexHTML;
                if (this.basePath) {
                    const baseHref = `<base href="${this.basePath}/">`;
                    if (!html.includes("<base")) {
                        html = html.replace("<head>", `<head>${baseHref}`);
                    } else {
                        html = html.replace(/<base[^>]*>/, baseHref);
                    }
                    // Prefix absolute paths with base path
                    html = html.replace(/(href|src)=["'](\/[^"']+)["']/g, (match, attr, path) => {
                        if (path.startsWith("//") || path.startsWith("http://") || path.startsWith("https://")) {
                            return match;
                        }
                        if (path.startsWith(this.basePath)) {
                            return match;
                        }
                        return `${attr}="${this.basePath}${path}"`;
                    });
                }
                response.send(html);
            });

            router.get("/api/entry-page", async (request, response) => {
                allowDevAllOrigin(response);
                response.json({
                    type: "setup-database",
                });
            });

            router.get("/setup-database-info", (request, response) => {
                allowDevAllOrigin(response);
                console.log("Request /setup-database-info");
                response.json({
                    runningSetup: this.runningSetup,
                    needSetup: this.needSetup,
                    isEnabledEmbeddedMariaDB: this.isEnabledEmbeddedMariaDB(),
                });
            });

            router.post("/setup-database", async (request, response) => {
                allowDevAllOrigin(response);

                if (this.runningSetup) {
                    response.status(400).json("Setup is already running");
                    return;
                }

                this.runningSetup = true;

                let dbConfig = request.body.dbConfig;

                let supportedDBTypes = [ "mariadb", "sqlite" ];

                if (this.isEnabledEmbeddedMariaDB()) {
                    supportedDBTypes.push("embedded-mariadb");
                }

                // Validate input
                if (typeof dbConfig !== "object") {
                    response.status(400).json("Invalid dbConfig");
                    this.runningSetup = false;
                    return;
                }

                if (!dbConfig.type) {
                    response.status(400).json("Database Type is required");
                    this.runningSetup = false;
                    return;
                }

                if (!supportedDBTypes.includes(dbConfig.type)) {
                    response.status(400).json("Unsupported Database Type");
                    this.runningSetup = false;
                    return;
                }

                // External MariaDB
                if (dbConfig.type === "mariadb") {
                    if (!dbConfig.hostname) {
                        response.status(400).json("Hostname is required");
                        this.runningSetup = false;
                        return;
                    }

                    if (!dbConfig.port) {
                        response.status(400).json("Port is required");
                        this.runningSetup = false;
                        return;
                    }

                    if (!dbConfig.dbName) {
                        response.status(400).json("Database name is required");
                        this.runningSetup = false;
                        return;
                    }

                    if (!dbConfig.username) {
                        response.status(400).json("Username is required");
                        this.runningSetup = false;
                        return;
                    }

                    if (!dbConfig.password) {
                        response.status(400).json("Password is required");
                        this.runningSetup = false;
                        return;
                    }

                    // Test connection
                    try {
                        log.info("setup-database", "Testing database connection...");
                        const connection = await mysql.createConnection({
                            host: dbConfig.hostname,
                            port: dbConfig.port,
                            user: dbConfig.username,
                            password: dbConfig.password,
                            database: dbConfig.dbName,
                        });
                        await connection.execute("SELECT 1");
                        connection.end();
                    } catch (e) {
                        response.status(400).json("Cannot connect to the database: " + e.message);
                        this.runningSetup = false;
                        return;
                    }
                }

                // Write db-config.json
                Database.writeDBConfig(dbConfig);

                response.json({
                    ok: true,
                });

                // Shutdown down this express and start the main server
                log.info("setup-database", "Database is configured, close the setup-database server and start the main server now.");
                if (tempServer) {
                    tempServer.close(() => {
                        log.info("setup-database", "The setup-database server is closed");
                        resolve();
                    });
                } else {
                    resolve();
                }

            });

            // Serve static files - must be before the catch-all route
            router.use("/", expressStaticGzip("dist", {
                enableBrotli: false,
                index: false,
                serveStatic: {
                    maxAge: 31536000,
                    etag: true,
                    fallthrough: true, // Fall through to next middleware if file not found
                },
                // Ensure static files are served correctly with base path
                customHeaders: (res, path) => {
                    // Set correct MIME type for JavaScript modules
                    if (path.endsWith(".js")) {
                        res.setHeader("Content-Type", "application/javascript");
                    }
                },
            }));

            router.get("*", async (request, response) => {
                // Skip if this is a request for static assets (they should be handled by expressStaticGzip)
                const url = request.url || request.originalUrl;
                if (url.match(/\.(js|css|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf|eot|json|xml|txt|map)$/i)) {
                    // This should have been handled by expressStaticGzip, return 404
                    response.status(404).send("File not found.");
                    return;
                }
                // Always use original HTML to avoid double injection
                let html = this.server.originalIndexHTML;
                if (this.basePath) {
                    const baseHref = `<base href="${this.basePath}/">`;
                    // Check if base tag already exists
                    if (!html.includes("<base")) {
                        html = html.replace("<head>", `<head>${baseHref}`);
                    } else {
                        html = html.replace(/<base[^>]*>/, baseHref);
                    }
                    // Prefix absolute paths with base path
                    // Note: <base> tag only affects relative paths, not absolute paths starting with /
                    html = html.replace(/(href|src)=["'](\/[^"']+)["']/g, (match, attr, path) => {
                        // Skip if it's already a full URL (http://, https://, //)
                        if (path.startsWith("//") || path.startsWith("http://") || path.startsWith("https://")) {
                            return match;
                        }
                        // Skip if path already starts with base path
                        if (path.startsWith(this.basePath)) {
                            return match;
                        }
                        return `${attr}="${this.basePath}${path}"`;
                    });
                }
                response.send(html);
            });

            router.options("*", async (_request, response) => {
                allowDevAllOrigin(response);
                response.end();
            });

            // Mount router to base path if needed
            if (this.basePath) {
                app.use(this.basePath, router);
                log.info("setup-database", `Setup database server mounted at base path: ${this.basePath}`);
            }

            tempServer = app.listen(port, hostname, () => {
                log.info("setup-database", `Starting Setup Database on ${port}`);
                let domain = (hostname) ? hostname : "localhost";
                const basePathInfo = this.basePath ? ` at ${this.basePath}` : "";
                log.info("setup-database", `Open http://${domain}:${port}${this.basePath || ""} in your browser`);
                log.info("setup-database", "Waiting for user action...");
            });
        });
    }
}

module.exports = {
    SetupDatabase,
};
